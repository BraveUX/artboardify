// shortcut command: shift+cmd+ctrl and <--
function renameArtboardsOnPage(context_){

        /*  First google hit    https://stackoverflow.com/questions/9229645/remove-duplicate-values-from-js-array#9229932   Thanks to George        https://stackoverflow.com/users/989121/georg        */
        function uniq(a) {return Array.from(new Set(a));} // cleans up duplicates

        var doc = MSDocument.currentDocument();
        var artboards = doc.currentPage().artboards();

        var xCount = []; 
        var yCount = [];  

        for (var i = 0; i < artboards.count(); i++){
            if(artboards[i].layers().count() > 1){
                yCount.push(   artboards[i].frame().y()  );
            }
        }

        yCount.sort(function(a, b){return a-b});
        yCount = uniq(yCount); 

        for (var p = 0; p < yCount.length; p++) {
            var rowY = yCount[p];                               // save the row number
            for (var i = 0; i < artboards.count(); i++){        // loop artboards
                var layerY = artboards[i].frame().y();
                var layerX = artboards[i].frame().x();

                if(layerY == rowY){                             // layer Y should match the row y to be added
                    var valueToPush = new Array();
                    valueToPush[0] = layerX;
                    valueToPush[1] = p;


                    if(artboards[i].layers().count() > 1){
                        xCount.push(valueToPush);                   // store new array containing the layer number and x pos
                    }
                }
            }
        }


        /*
            Assign the names row by row
        */
        var currentArtboardnumbers = new Array();

        for (var p = 0; p < yCount.length; p++) {               // loop door rows
            var rowXposses = [];

            for (var i = 0; i < xCount.length; i++) if(xCount[i][1] == p)rowXposses.push(xCount[i][0]);              
            rowXposses.sort(function(a, b){return a-b});

            for (var i = 0; i < artboards.count(); i++){
                var yIndex = yCount.indexOf(artboards[i].frame().y()); // find the current y row based on y value.
                if(yIndex == p){    // y index pos should match the current row number.
                    var xIndex = rowXposses.indexOf(artboards[i].frame().x());
                    
                    //var xIndex = String.fromCharCode(97 + xIndex); // basic solution, does not account for chars past 27
                    //similar to this https://stackoverflow.com/questions/22624379/how-to-convert-letters-to-numbers-with-javascript

                    function AlphaNum(i) {
                        return (i >= 26 ? AlphaNum((i / 26 >> 0) - 1) : '') +  'abcdefghijklmnopqrstuvwxyz'[i % 26 >> 0]; //recursive to start duplicating char values past 27
                    }
                    var xIndex = AlphaNum(0 + xIndex);

                    var layerNameBase = artboards[i].name().split("_ "); // split a base
                    layerNameBase = layerNameBase[layerNameBase.length-1]; // remove the old numbers and save base

                   // remove the Copy + space + number
                   if(layerNameBase.includes(" Copy")){
                       layerNameBase = layerNameBase.replace(/\s+/g, ' ');
                       layerNameBase = layerNameBase.substring(0, layerNameBase.indexOf('Copy'));
                    

            }

                   var name = yIndex + xIndex + "_ " + layerNameBase;    // create the name

                   artboards[i].setName(name);

                   var ab_number = yIndex + (xIndex /10);
                   console.log("ab_number: "+ ab_number);

                   var ab_numberToPush = new Array();
                   ab_numberToPush[0] = ab_number;
                   ab_numberToPush[1] = artboards[i];

                   currentArtboardnumbers.push(ab_numberToPush)//  store names to be sorted and artboard reordering

                }
            }
        }

        for (var i = 0; i < artboards.count(); i++){
            if(artboards[i].layers().count() <= 1){
                console.log(artboards[i].name());
                artboards[i].setName("_ ");
            }
        }
        // currentArtboardnumbers.sort(function(a, b){return a-b});
        // console.log("##{#{#{#{}}}} 1");
        // console.log(currentArtboardnumbers);

        currentArtboardnumbers.sort(sortFunction);
        // First answer: https://stackoverflow.com/questions/16096872/how-to-sort-2-dimensional-array-by-column-value
        function sortFunction(a, b) {
            if (a[0] === b[0]) {
                return 0;
            }
            else {
                return (a[0] < b[0]) ? -1 : 1;
            }
        }


        // apply page order.
        //for (var i = 0; i < currentArtboardnumbers.length; i++){
         //   var layer = currentArtboardnumbers[i][1];
         //   MSLayerMovement.moveToBack([layer]);
         //}


         
        context_.document.showMessage("Artboards Renamed");
 }




